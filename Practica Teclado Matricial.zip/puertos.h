#ifndef PORT_H
#define PORT_H
 
#include "main.h"
 
/* prototipos */
void inicializar_puertos(void);
uint8_t leer_keypad(void);
 
#endif  /* PORT_H */